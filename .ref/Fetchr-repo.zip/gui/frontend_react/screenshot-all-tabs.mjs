import { chromium } from 'playwright';
import { mkdirSync } from 'fs';

mkdirSync('./screenshots', { recursive: true });

const browser = await chromium.launch();
const context = await browser.newContext({
  viewport: { width: 1020, height: 720 },
  deviceScaleFactor: 2,
});
const page = await context.newPage();
await page.goto('http://localhost:5175', { waitUntil: 'networkidle', timeout: 10000 });
await page.waitForTimeout(600);

// Tab: Download (default)
await page.screenshot({ path: './screenshots/tab-download.png' });

// Tab: Queue
await page.click('button:has-text("Queue")');
await page.waitForTimeout(300);
await page.screenshot({ path: './screenshots/tab-queue.png' });

// Tab: History
await page.click('button:has-text("History")');
await page.waitForTimeout(300);
await page.screenshot({ path: './screenshots/tab-history.png' });

await browser.close();
console.log('Done');
