import { chromium } from 'playwright';
import { mkdirSync } from 'fs';

mkdirSync('./screenshots', { recursive: true });

const browser = await chromium.launch();
const context = await browser.newContext({
  viewport: { width: 1440, height: 900 },
  deviceScaleFactor: 2,
});

const page = await context.newPage();

try {
  await page.goto('http://localhost:5175', { waitUntil: 'networkidle', timeout: 10000 });
  await page.waitForTimeout(800);
  await page.screenshot({ path: './screenshots/current-ui.png', fullPage: true });
  console.log('Screenshot saved: screenshots/current-ui.png');
} catch (e) {
  console.error('Error:', e.message);
}

await browser.close();
